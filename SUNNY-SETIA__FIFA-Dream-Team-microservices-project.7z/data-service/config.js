const DB_Info={
    password:'xx',
    username:'xx'
}

module.exports = DB_Info
